#include "Node.h"


Node::Node(int data, Node * left, Node * right) {
	value = data;
	left = NULL;
	right = NULL;
}

Node::~Node() {}

int Node::getData() const {
	return value;
}

Node * Node::getLeftChild() const {
	return left;
}

Node * Node::getRightChild() const {
	return right;
}
